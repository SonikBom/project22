<?php 
// src/Controller/MainController.php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

// MainController - класс контроллер Symfony
class MainController {

    #[Route('/api', methods: ['GET'])]
    public function index() : Response {
        return new Response('server is running');
    }

    #[Route('/api/ping', methods: ['GET'])]
    public function ping() : Response {
        return new Response('pong');
    }
}